import json
import glob
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def process_json_files(file_pattern='*.json'):
    """
    Process multiple JSON files and combine their data into a DataFrame.
    
    Args:
        file_pattern (str): Globe pattern to match JSON files
        
    Returns:
        tuple: (DataFrame of error data, DataFrame of reactive results)
    """
    all_error_data = []
    all_reactive_data = []
    for filename in glob.glob(file_pattern):
        with open(filename, 'r') as f:
            data = json.load(f)
            reactive_row = {
                'filename': filename,
                **data.get('reactive_results', {}).get('ObjectsMissed', {})
            }
            all_reactive_data.append(reactive_row)
            results = data.get('results', {})
            for error_type, error_data in results.items():
                for instance_num, instance_data in error_data.items():
                    row = {
                        'error_type': error_type,
                        'instance': int(instance_num),
                        'missed': instance_data['missed'],
                        'time': instance_data['time'],
                        'filename': filename
                    }
                    all_error_data.append(row)

    error_df = pd.DataFrame(all_error_data)
    reactive_df = pd.DataFrame(all_reactive_data)
    return error_df, reactive_df


def analyze_data(error_df, reactive_df):
    """
    Generate summary statistics from the processed data.
    
    Args:
        error_df (pd.DataFrame): Processed error data
        reactive_df (pd.DataFrame): Processed reactive results
        
    Returns:
        dict: Summary statistics
    """
    summary = {
        'error_statistics': {
            'total_errors': len(error_df),
            'errors_by_type': error_df.groupby('error_type').size().to_dict(),
            'missed_by_type': error_df[error_df['missed']].groupby('error_type').size().to_dict(),
            'avg_time_by_type': error_df.groupby('error_type')['time'].mean().to_dict(),
            'total_instances': error_df['instance'].nunique()
        },
        'reactive_statistics': {
            'total_files': len(reactive_df),
            'total_rows_missed': reactive_df['rows'].sum(),
            'total_structures_missed': reactive_df['structures'].sum(),
            'avg_rows_missed': reactive_df['rows'].mean(),
            'avg_structures_missed': reactive_df['structures'].mean()
        }
    }    
    return summary


def create_visualizations(error_df, reactive_df):
    """
    Create and save visualizations of the error data.
    """
    plt.style.use('default')
    plt.rcParams['figure.figsize'] = (10, 6)
    plt.rcParams['axes.grid'] = True
    plt.rcParams['grid.alpha'] = 0.3
    plt.figure(figsize=(10, 6))
    error_counts = error_df['error_type'].value_counts()
    colors = sns.color_palette('husl', len(error_counts))
    error_counts.plot(kind='bar', color=colors)
    plt.title('Distribution of Error Types')
    plt.xlabel('Error Type')
    plt.ylabel('Count')
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig('error_distribution.png', dpi=300, bbox_inches='tight')
    plt.figure(figsize=(10, 6))
    instance_matrix = pd.crosstab(error_df['instance'], error_df['error_type'])
    sns.heatmap(instance_matrix, annot=True, cmap='YlOrRd', fmt='d')
    plt.title('Error Instances Heatmap')
    plt.tight_layout()
    plt.savefig('error_heatmap.png', dpi=300, bbox_inches='tight')
    plt.figure(figsize=(10, 6))
    missed_matrix = pd.crosstab(error_df['error_type'], error_df['missed'])
    missed_matrix.plot(kind='bar', stacked=True)
    plt.title('Missed vs Caught Errors by Type')
    plt.xlabel('Error Type')
    plt.ylabel('Count')
    plt.legend(title='Missed', labels=['Caught', 'Missed'])
    plt.tight_layout()
    plt.savefig('missed_errors.png', dpi=300, bbox_inches='tight')

    if error_df['time'].any():
        plt.figure(figsize=(10, 6))
        error_df.boxplot(column='time', by='error_type')
        plt.title('Error Time Distribution by Type')
        plt.suptitle('')
        plt.ylabel('Time')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('time_distribution.png', dpi=300, bbox_inches='tight')

    if len(reactive_df) > 0:
        plt.figure(figsize=(10, 6))
        reactive_df[['rows', 'structures']].plot(kind='bar')
        plt.title('Reactive Results: Missed Objects by File')
        plt.xlabel('File Index')
        plt.ylabel('Count')
        plt.legend(title='Missed Objects')
        plt.tight_layout()
        plt.savefig('reactive_results.png', dpi=300, bbox_inches='tight')
    plt.close('all')


def main():
    """
    Main function to process data and generate visualizations.
    """
    error_df, reactive_df = process_json_files('*.json')
    summary = analyze_data(error_df, reactive_df)
    print("\nSummary Statistics:")
    print(json.dumps(summary, indent=2, default=str))
    create_visualizations(error_df, reactive_df)
    print("\nVisualizations have been saved as:")
    print("- error_distribution.png (distribution of error types)")
    print("- error_heatmap.png (instance vs error type)")
    print("- missed_errors.png (missed vs caught errors)")
    print("- reactive_results.png (reactive results overview)")
    if error_df['time'].any():
        print("- time_distribution.png (time distribution by error type)")


if __name__ == '__main__':
    main()